# IoT Button V2 深度睡眠示例

基于 ESP32-C6 的低功耗物联网按钮实现，具备深度睡眠功能，通过 SeeedHADiscovery 库与 Home Assistant 集成。

## 功能特性

### 📶 WiFi 网页配网（新功能！）
- **网页配置**：无需在代码中硬编码 WiFi 凭据
- **强制门户**：首次启动时，设备创建 AP "Seeed_IoT_Button_V2_AP"
- **简单设置**：连接到 AP，打开浏览器，选择网络，输入密码
- **凭据持久化**：WiFi 设置保存到 Flash，重启后依然有效
- **长按重置**：在配网模式下，长按清除凭据

### 🔘 多击按键检测
- **单击**：切换开关 1 + 粉紫色闪烁灯效
- **双击**：切换开关 2 + 橙色微闪灯效
- **三击**：切换开发者模式（3 分钟休眠超时，便于上传固件）
- **长按（1-5秒）**：切换开关 3 + 彩虹渐变灯效
- **长按（6秒以上）**：重置 WiFi 凭据并启动 AP 模式重新配网

### 🔋 电池监测
- 通过 ADC 实时测量电池电压
- 电池百分比计算（2.75V = 0%，4.2V = 100%）
- 防跳变滤波器，防止百分比波动
- 持久化存储上次电池百分比

### 💤 深度睡眠模式
- 超低功耗（深度睡眠约 10µA）
- GPIO 唤醒，按键触发
- 智能休眠超时：
  - **HA 已连接**：10 秒无活动
  - **HA 未连接**：3 分钟无活动
  - **开发者模式**：3 分钟（便于固件上传）
- 每次按键操作都会重置休眠计时器

### 🌈 RGB LED 灯效
- **闪烁**：粉紫色闪烁（开关 1）
- **微闪**：橙色呼吸效果（开关 2）
- **彩虹**：平滑颜色渐变（开关 3）
- **随机颜色**：随机颜色过渡（开发模式）

### 🏠 Home Assistant 集成
- 通过 WebSocket 自动发现
- 暴露的实体：
  - 电池电压（传感器）
  - 电池百分比（传感器）
  - 按钮状态（传感器）
  - 开关 1/2/3（开关）
- 双向控制（设备 ↔ Home Assistant）
- 深度睡眠周期间状态持久化

## 硬件要求

### 平台
- **MCU**：ESP32-C6 (esp32-c6-devkitc-1)
- **Flash**：4MB
- **CPU**：80MHz（低功耗优化）

### 引脚配置

| 引脚 | 功能 | 描述 |
|-----|------|------|
| GPIO0 | 输出 | 电池电压检测使能（HIGH = 使能） |
| GPIO1 | ADC | 电池电压输入（12dB 衰减，×4.0 乘数） |
| GPIO2 | 输入 | 按钮（上拉，反向逻辑，唤醒源） |
| GPIO3 | 输出 | 蓝色 LED（反向逻辑，LOW = 点亮） |
| GPIO14 | 输出 | 红色 LED（反向逻辑，LOW = 点亮） |
| GPIO18 | 输出 | LED 灯带电源使能（HIGH = 使能） |
| GPIO19 | 输出 | WS2812 RGB LED 数据线（单颗灯珠，GRB 顺序） |

### 电路说明
- 按钮连接 GPIO2 到 GND（内部上拉已启用）
- LED 使用反向逻辑（LOW = 点亮，HIGH = 熄灭）
- 电池电压分压器需要 4.0× 乘数得到实际电压

## 软件依赖

### 需要安装的库

通过 Arduino 库管理器安装以下库（**项目** → **加载库** → **管理库...**）：

| 库名称 | 作者 | 版本 | 说明 |
|-------|------|------|------|
| **ArduinoJson** | Benoit Blanchon | ≥ 6.x | JSON 解析，用于 HA 通信 |
| **WebSockets** | Markus Sattler | ≥ 2.x | WebSocket 客户端/服务器 |
| **Adafruit NeoPixel** | Adafruit | ≥ 1.x | WS2812 RGB LED 控制 |

**安装步骤**：
1. 打开 Arduino IDE
2. 点击 **项目** → **加载库** → **管理库...**
3. 在搜索框中输入库名称
4. 找到对应的库，点击 **安装**

### 内置库（无需安装）

以下库已包含在 ESP32 Arduino 核心中：

- **Preferences** - 非易失性存储
- **WiFi** - WiFi 连接
- **esp_sleep.h** - 深度睡眠功能
- **driver/gpio.h** - GPIO 控制

### SeeedHADiscovery 库

此库需要手动安装：

**方法一：ZIP 安装**
1. 从 [GitHub](https://github.com/limengdu/SeeedHADiscovery) 下载 ZIP 文件
2. 在 Arduino IDE 中：**项目** → **加载库** → **添加 .ZIP 库...**
3. 选择下载的 ZIP 文件

**方法二：Git 克隆**
```bash
cd ~/Documents/Arduino/libraries
git clone https://github.com/limengdu/SeeedHADiscovery.git
```

### ESP32 开发板包

确保已安装 ESP32 开发板包：

1. 打开 **文件** → **首选项**
2. 在"附加开发板管理器网址"中添加：
   ```
   https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
   ```
3. 打开 **工具** → **开发板** → **开发板管理器...**
4. 搜索 "esp32"，安装 **esp32 by Espressif Systems**（推荐版本 ≥ 3.x）

## 快速开始

### 1. 配置 WiFi（选择一种方式）

#### 方式 A：网页配网（推荐）

无需修改代码！通过浏览器配置 WiFi：

1. 上传程序（`USE_WIFI_PROVISIONING` 设置为 `true`）
2. 首次启动时，设备创建 AP：**Seeed_IoT_Button_V2_AP**
3. 用手机/电脑连接到此 AP
4. 浏览器自动打开，或手动访问 `http://192.168.4.1`
5. 选择你的 WiFi 网络并输入密码
6. 设备保存凭据并重启

#### 方式 B：硬编码凭据

将 `USE_WIFI_PROVISIONING` 设置为 `false` 并编辑凭据：

```cpp
#define USE_WIFI_PROVISIONING false

const char* WIFI_SSID = "你的WiFi名称";
const char* WIFI_PASSWORD = "你的WiFi密码";
```

### 2. 上传程序

1. 选择开发板：**XIAO ESP32C6**
2. 配置设置：
   - Flash Size: 4MB
   - CPU Frequency: 80MHz（推荐低功耗）
   - **Partition Scheme（分区方案）: "Huge APP (3MB No OTA/1MB SPIFFS)"** ⚠️ 重要！
   - Upload Speed: 921600
3. 上传程序

> ⚠️ **重要**：如果看到错误 `text section exceeds available space in board`，必须更改分区方案。进入 **工具** → **Partition Scheme（分区方案）**，选择 **"Huge APP (3MB No OTA/1MB SPIFFS)"** 或 **"Minimal SPIFFS (1.9MB APP with OTA/190KB SPIFFS)"**。

### 3. 添加到 Home Assistant

1. 打开 Home Assistant
2. 进入 **设置** → **设备与服务** → **添加集成**
3. 搜索 **Seeed HA Discovery**
4. 输入设备 IP 地址（在串口监视器中显示）
5. 完成设置

## LED 状态指示

| LED | 状态 | 含义 |
|-----|------|------|
| 红色 | 常亮 | WiFi 断开 / 正在连接 |
| 蓝色 | 常亮 | WiFi 已连接 |
| 红+蓝 | 交替（5次） | WiFi 配网模式已激活 |
| 红+蓝 | 闪烁（3次） | 开发者模式已启用 |
| RGB | 各种灯效 | 按键操作反馈 |

## WiFi 配网模式

当 `USE_WIFI_PROVISIONING` 启用（默认）时，设备使用网页配网：

### 首次启动 / 无凭据
1. 设备创建 AP 热点：**Seeed_IoT_Button_V2_AP**
2. 红/蓝 LED 交替闪烁表示配网模式
3. 用手机或电脑连接到 AP
4. 浏览器自动打开强制门户
5. 如果没有自动打开，手动访问 `http://192.168.4.1`

### 配置界面
- **网络列表**：显示可用的 WiFi 网络及信号强度
- **安全**：锁图标表示需要密码的网络
- **刷新**：点击重新扫描网络
- **重置**：清除保存的凭据

### 配网模式控制
- **长按（1-5秒）**：清除保存的 WiFi 凭据并重启
- **任意按键操作**：重置 3 分钟超时计时器
- **3 分钟**无操作后设备将进入深度睡眠以保护电池
- 这对于出厂固件很重要 - 设备可能在包装中放置数月！

### 重新配置 WiFi
要更改 WiFi 设置：
1. 在配网模式下长按按钮，或
2. 在代码中调用 `ha.clearWiFiCredentials()` 并重新上传

## 开发者模式

三击按钮启用开发者模式：

- 将休眠超时延长至 3 分钟
- 允许有足够时间上传固件而不会进入休眠
- 视觉指示：双灯闪烁 3 次 + 随机颜色 RGB 灯效
- 再次三击可禁用

## 休眠行为

设备在一段时间无活动后自动进入深度睡眠：

| 条件 | 超时时间 | 说明 |
|------|---------|------|
| HA 已连接 | 10 秒 | 快速休眠以节省电量 |
| HA 未连接 | 3 分钟 | 较长超时用于连接尝试 |
| 开发者模式 | 3 分钟 | 延长超时用于开发 |

**重要**：每次按键操作都会重置休眠计时器。

## 按键检测时序

| 操作 | 按下时长 | 释放间隔 |
|------|---------|---------|
| 单击 | ≤ 1 秒 | 0.5 秒内无下次按下 |
| 双击 | 每次 ≤ 1 秒 | 两次点击间隔 ≤ 1 秒 |
| 三击 | 每次 ≤ 0.8 秒 | 点击间隔 ≤ 0.8 秒 |
| 长按（开关 3） | 1-5 秒 | 不适用 |
| 长按（WiFi 重置） | ≥ 6 秒 | 不适用 |

> **注意**：6 秒 WiFi 重置功能在**唤醒状态和从深度睡眠唤醒时**都能工作。只需在任何时候按住按钮 6 秒以上即可重置 WiFi 凭据并进入 AP 模式。

## 持久化存储

以下数据保存到 Flash，在深度睡眠/重启后保留：

- WiFi 凭据（SSID 和密码）- 如果使用配网功能
- 开关 1/2/3 状态
- 上次电池百分比（用于防跳变滤波器）

## 功耗

| 模式 | 电流 | 说明 |
|------|------|------|
| 活动（WiFi） | 约 80-150mA | 取决于 WiFi 活动 |
| 深度睡眠 | 约 10µA | 已配置 GPIO 唤醒 |

## 故障排除

### "text section exceeds available space in board" 编译错误
- 此错误表示代码太大，超出了默认分区方案的空间
- **解决方案**：进入 **工具** → **Partition Scheme（分区方案）** → 选择 **"Huge APP (3MB No OTA/1MB SPIFFS)"**
- 备选方案：选择 **"Minimal SPIFFS (1.9MB APP with OTA/190KB SPIFFS)"**

### 设备无法从深度睡眠唤醒
- 确保 GPIO2 正确连接到按钮
- 检查按下按钮时是否将 GPIO2 拉到 GND

### WiFi 连接失败
- 验证 SSID 和密码是否正确
- 检查 WiFi 信号强度
- 如果连接失败，红色 LED 会持续闪烁

### 重置后开关显示为开启状态
- 当前版本已修复此问题
- 在创建开关之前从 Flash 加载状态

### 电池百分比意外跳变
- 防跳变滤波器会阻止小于 5% 的增量
- 为获得准确读数，请确保电压分压器已校准

## 串口监视器输出

通过串口监视器连接（115200 波特率）可查看：
- 启动原因（全新启动 / 深度睡眠唤醒）
- WiFi 连接状态
- 检测到的按键事件
- 开关状态变化
- 休眠超时倒计时
- 电池读数

## 使用流程示例

### 基本使用

1. **上电启动**
   - 红色 LED 亮起表示正在连接 WiFi
   - 蓝色 LED 亮起表示 WiFi 已连接
   
2. **按键操作**
   - 单击按钮切换开关 1
   - 观察 RGB LED 显示粉紫色闪烁效果
   
3. **自动休眠**
   - HA 连接后 10 秒无操作自动进入深度睡眠
   - 按下按钮唤醒设备

### 开发调试

1. **进入开发模式**
   - 快速三击按钮
   - 观察双 LED 闪烁 3 次确认
   
2. **上传新固件**
   - 在 3 分钟内完成固件上传
   - 设备不会进入休眠
   
3. **退出开发模式**
   - 再次三击按钮
   - 或等待 3 分钟自动休眠

## 代码结构

```
IoTButtonV2_DeepSleep.ino
├── 配置区域
│   ├── WiFi 配置
│   ├── 引脚定义
│   └── 时间常量
├── LED 控制函数
├── RGB LED 灯效函数
├── 电池监测函数
├── 按键检测函数
├── 开关动作函数
├── WiFi 事件处理
├── 休眠函数
├── 持久化存储函数
└── Arduino 主程序
    ├── setup() - 初始化
    └── loop() - 主循环
```

## 自定义修改

### 修改休眠超时

编辑以下常量（单位：毫秒）：

```cpp
#define INACTIVITY_TIMEOUT_HA_CONNECTED 10000   // HA 连接后超时
#define INACTIVITY_TIMEOUT_NOT_CONNECTED 180000 // HA 未连接超时
#define INACTIVITY_TIMEOUT_DEV_MODE 180000      // 开发模式超时
```

### 修改按键时序

```cpp
#define LONG_PRESS_MIN_TIME 1000      // 长按最小时间
#define LONG_PRESS_MAX_TIME 5000      // 长按最大时间
#define SINGLE_CLICK_MAX_TIME 1000    // 单击最大按下时间
#define SINGLE_CLICK_WAIT_TIME 500    // 单击确认等待时间
#define DOUBLE_CLICK_GAP_TIME 1000    // 双击最大释放间隔
```

### 修改 RGB 灯效

灯效持续时间：
```cpp
#define RGB_EFFECT_DURATION 1000  // 灯效持续时间（毫秒）
```

## 许可证

本示例是 SeeedHADiscovery 库的一部分。

## 支持

如有问题和功能请求，请访问 [GitHub 仓库](https://github.com/limengdu/SeeedHADiscovery)。

